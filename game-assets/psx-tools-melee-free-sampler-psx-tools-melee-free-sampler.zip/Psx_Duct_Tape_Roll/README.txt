PSX Duct Tape Roll
==================

Authentic PS1-style low-poly game asset.

Triangles: 84
Objects: duct_tape_roll (84 tris)
Size: 0.12 x 0.12 x 0.05 m (real-world scale, 1 unit = 1 metre)
Texture: 64x64 px, 12 colours, one atlas (textures/psx_duct_tape_roll_diffuse.png)
Use nearest-neighbour ("point") filtering and no mipmaps for the authentic look.
Pivot: bottom centre.
Axes: FBX/OBJ are Y-up, -Z forward (Unity / Unreal / Godot ready). GLB follows glTF conventions.

Files:
  psx_duct_tape_roll.fbx
  psx_duct_tape_roll.obj
  psx_duct_tape_roll.mtl
  psx_duct_tape_roll.glb
  collision/psx_duct_tape_roll_collision.fbx
  psx_duct_tape_roll.blend
  textures/psx_duct_tape_roll_diffuse.png

collision/ holds a simple convex collision mesh (UCX_ prefix = Unreal custom collision).

Made by ATR0CITY.