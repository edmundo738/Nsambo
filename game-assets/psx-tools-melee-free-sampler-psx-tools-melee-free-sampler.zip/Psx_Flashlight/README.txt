PSX Flashlight
==============

Authentic PS1-style low-poly game asset.

Triangles: 170
Objects: flashlight (170 tris)
Size: 0.32 x 0.05 x 0.05 m (real-world scale, 1 unit = 1 metre)
Texture: 128x128 px, 12 colours, one atlas (textures/psx_flashlight_diffuse.png)
Use nearest-neighbour ("point") filtering and no mipmaps for the authentic look.
Pivot: bottom centre.
Axes: FBX/OBJ are Y-up, -Z forward (Unity / Unreal / Godot ready). GLB follows glTF conventions.

Files:
  psx_flashlight.fbx
  psx_flashlight.obj
  psx_flashlight.mtl
  psx_flashlight.glb
  collision/psx_flashlight_collision.fbx
  psx_flashlight.blend
  textures/psx_flashlight_diffuse.png

collision/ holds a simple convex collision mesh (UCX_ prefix = Unreal custom collision).

Made by ATR0CITY.