PSX Screwdriver
===============

Authentic PS1-style low-poly game asset.

Triangles: 92
Objects: psx_screwdriver (92 tris)
Size: 0.20 x 0.03 x 0.03 m (real-world scale, 1 unit = 1 metre)
Texture: 64x64 px, 20 colours, one atlas (textures/psx_screwdriver_diffuse.png)
Use nearest-neighbour ("point") filtering and no mipmaps for the authentic look.
Pivot: bottom centre.
Axes: FBX/OBJ are Y-up, -Z forward (Unity / Unreal / Godot ready). GLB follows glTF conventions.

Files:
  psx_screwdriver.fbx
  psx_screwdriver.obj
  psx_screwdriver.mtl
  psx_screwdriver.glb
  collision/psx_screwdriver_collision.fbx
  psx_screwdriver.blend
  textures/psx_screwdriver_diffuse.png

collision/ holds a simple convex collision mesh (UCX_ prefix = Unreal custom collision).

Photo sources used in the texture (all CC0 / public domain):
  Metal009 - ambientCG - https://ambientcg.com/view?id=Metal009
  Plastic013A - ambientCG - https://ambientcg.com/view?id=Plastic013A

Made by ATR0CITY.