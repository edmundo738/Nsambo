PSX Crowbar
===========

Authentic PS1-style low-poly game asset.

Triangles: 136
Objects: crowbar (136 tris)
Size: 0.76 x 0.12 x 0.02 m (real-world scale, 1 unit = 1 metre)
Texture: 128x128 px, 13 colours, one atlas (textures/psx_crowbar_diffuse.png)
Use nearest-neighbour ("point") filtering and no mipmaps for the authentic look.
Pivot: bottom centre.
Axes: FBX/OBJ are Y-up, -Z forward (Unity / Unreal / Godot ready). GLB follows glTF conventions.

Files:
  psx_crowbar.fbx
  psx_crowbar.obj
  psx_crowbar.mtl
  psx_crowbar.glb
  collision/psx_crowbar_collision.fbx
  psx_crowbar.blend
  textures/psx_crowbar_diffuse.png

collision/ holds a simple convex collision mesh (UCX_ prefix = Unreal custom collision).

Photo sources used in the texture (all CC0 / public domain):
  Metal009 - ambientCG - https://ambientcg.com/view?id=Metal009

Made by ATR0CITY.