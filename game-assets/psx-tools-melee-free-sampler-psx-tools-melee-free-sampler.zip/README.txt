PSX Tools & Melee - Free Sampler - PSX asset pack by ATR0CITY

5 authentic PS1-style low-poly asset(s). Each folder has FBX, OBJ, GLB and BLEND files,
a PS1 texture (use nearest-neighbour filtering), a README with its specs and a renders/ folder
(studio shots, PSX in-game scenes, wireframes, texture sheet and UV layout).
icons/: 512 px and 256 px transparent inventory icons for every model.

- PSX Crowbar
- PSX Screwdriver
- PSX Flashlight
- PSX Duct Tape Roll
- PSX Pickup Marker

PLACEMENT NOTES
Part of PSX Survival Horror Essentials: pickup-ready items for PS1-style survival horror games.
SCALE: real-world metres (the screwdriver is 20 cm long, the fire axe 90 cm, the shovel 1.45 m).
PIVOT: bottom centre of each model's bounding box, bottom at z = 0, so items drop straight onto workbenches and floors.
ORIENTATION: items lie as they would on a workbench. Long tools and weapons lie along X with the head, blade or lens toward +X. Labels face -Y.
PICKUP MARKER: a flat emissive ring (cutout texture) to place under any item so players spot it. Optional, never baked into an item.
ICONS: icons/ has a 512 px and a 256 px transparent PNG for every model, same camera and lighting for all, ready for inventory screens.
Tools and blades are inspired by real-world designs and carry no brands, logos or markings.

This is a free 5-piece sample of PSX Tools & Melee. The full pack has 17 models.

Modelled with AI assistance and hand-checked by ATR0CITY.